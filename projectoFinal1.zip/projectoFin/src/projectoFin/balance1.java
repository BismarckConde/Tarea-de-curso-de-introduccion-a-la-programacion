package projectoFin;
import java.util.ArrayList;
public class balance1 {
    protected static ArrayList<Cuenta> activosCirculantes = new ArrayList<>();
    protected static ArrayList<Cuenta> activosFijos = new ArrayList<>();
    protected static ArrayList<Cuenta> activosDiferidos = new ArrayList<>();
    protected static ArrayList<Cuenta> pasivosCirculantes = new ArrayList<>();
    protected static ArrayList<Cuenta> pasivosNoCirculantes = new ArrayList<>();
    protected static ArrayList<Cuenta> capital = new ArrayList<>();
    protected static int PasivosMasCapital = 0;
    protected static int depreciacionAcumulada = 0;
    protected static int TotalActivos = 0;
    protected static int TotalPasivos = 0;
    protected static String fechaBalance = "";
    protected static String NombreEmpresa = "";
}
