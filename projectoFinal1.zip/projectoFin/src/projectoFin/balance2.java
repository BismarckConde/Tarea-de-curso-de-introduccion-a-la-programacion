package projectoFin;

import javax.swing.JOptionPane;
public class balance2 extends balance1{
public static void mostrarTodasLasCuentas() {
    	
    	System.out.println(NombreEmpresa+"\n");
        System.out.println("          Balance General\n");
        System.out.println(fechaBalance + "\n");
        
        System.out.println("---------------------------------------");

        System.out.println("|Activos|");
        System.out.println("Activos Circulantes");
        for (Cuenta cuenta : activosCirculantes) {
            System.out.println(cuenta.getNombre() + ": " + cuenta.getValor());
        }
        System.out.println("Total Activos Circulantes: " + calcularTotalActivosCirculantes());

        System.out.println("\nActivos Fijos");
        for (Cuenta cuenta : activosFijos) {
            System.out.println(cuenta.getNombre() + ": " + cuenta.getValor());
        }
        System.out.println("Total Activos Fijos: " + calcularTotalActivosFijos());

        System.out.println("\nActivos Diferidos");
        for (Cuenta cuenta : activosDiferidos) {
            System.out.println(cuenta.getNombre() + ": " + cuenta.getValor());
        }
        System.out.println("Total Activos Diferidos: " + calcularTotalActivosDiferidos());
        
        System.out.println("---------------------------------------");        
        TotalActivos = calcularTotalActivosDiferidos() + calcularTotalActivosFijos() + calcularTotalActivosCirculantes();
        System.out.println("Total Activos: " + TotalActivos);       
        System.out.println("---------------------------------------");

        System.out.println("\n|Pasivos|");
        System.out.println("Pasivos Circulantes");
        for (Cuenta cuenta : pasivosCirculantes) {
            System.out.println(cuenta.getNombre() + ": " + cuenta.getValor());
        }
        System.out.println("Total Pasivos Circulantes: " + calcularTotalPasivosCirculantes());

        System.out.println("\nPasivos No Circulantes");
        for (Cuenta cuenta : pasivosNoCirculantes) {
            System.out.println(cuenta.getNombre() + ": " + cuenta.getValor());
        }
        System.out.println("Total Pasivos No Circulantes: " + calcularTotalPasivosNoCirculantes());
        
        System.out.println("---------------------------------------");        
        TotalPasivos = calcularTotalPasivosNoCirculantes() + calcularTotalPasivosCirculantes();
        System.out.println("Total Pasivos: " + TotalPasivos);
        System.out.println("---------------------------------------");
        
        System.out.println("\n|Capital|");
        for (Cuenta cuenta : capital) {
            System.out.println(cuenta.getNombre() + ": " + cuenta.getValor());
        }
        
        System.out.println("---------------------------------------");
        System.out.println("Total Capital: " + calcularTotalCapital());
        System.out.println("---------------------------------------");
        PasivosMasCapital=calcularTotalCapital() + calcularTotalPasivosCirculantes() 
        + calcularTotalPasivosNoCirculantes();
        
        
        System.out.println("\n\n\n---------------------------------------");
        
        System.out.println("Pasivos + Capital: "+PasivosMasCapital);
        System.out.println("Total Activos: " + TotalActivos);
        System.out.println("---------------------------------------");
    }

    public static void IngresarNombre(){
    	
    	NombreEmpresa = JOptionPane.showInputDialog("Ingrese el nombre de la empresa:");
    }
    
    
    public static void mostrarMenuPrincipal() {
        String menu = "Balance General\n\n" +
                "1. Ingrear datos del Balance General\n" +
                "2. Mostrar Balance General\n" +
                "3. Salir\n"+
                "\nIngresa una opcion:";

        boolean salir = false;

        while (!salir) {
            String opcion = JOptionPane.showInputDialog(null, menu);
            switch (opcion) {
                case "1":
                    mostrarMenuIngresoDatos();
                    break;
                case "2":
                    mostrarTodasLasCuentas();
                    break;
                case "3":
                    salir = true;
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción inválida");
                    break;
            }
        }
    }

    public static void mostrarMenuIngresoDatos() {
        String menu = "Menu de Ingreso de Datos\n\n" +
                "1. Ingresar el nombre de la empresa\n"+
                "2. Ingresar Activos\n" +
                "3. Ingresar Pasivos\n" +
                "4. Ingresar Capital\n" +
                "5. Ingresar fecha\n"+
                "6. Volver\n"+
                "\nIngresa una opcion:";

        boolean volver = false;

        while (!volver) {
            String opcion = JOptionPane.showInputDialog(null, menu);
            switch (opcion) {
            
                case "1":
                	IngresarNombre();
                	break;
                case "2":
                    mostrarMenuActivos();
                    break;
                case "3":
                    mostrarMenuPasivos();
                    break;
                case "4":
                    ingresarCuentasCapital();
                    break;
                case "5":
                	ingresarFechaBalance();
                    break;
                case "6":
                    volver = true;
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción inválida");
                    break;
            }
        }
    }

    public static void ingresarFechaBalance() {
        fechaBalance = JOptionPane.showInputDialog("Ingrese la fecha de realización del Balance General");
        JOptionPane.showMessageDialog(null, "Fecha de Balance agregada exitosamente");
    }

    public static void mostrarMenuActivos() {
        String menu = "Menu de Activos\n\n" +
                "1. Activo Circulante\n" +
                "2. Activos Fijos\n" +
                "3. Activos Diferidos\n" +
                "4. Volver al Menú de Ingreso de Datos";

        boolean volver = false;

        while (!volver) {
            String opcion = JOptionPane.showInputDialog(null, menu);
            switch (opcion) {
                case "1":
                    ingresarCuentasActivosCirculantes();
                    break;
                case "2":
                    ingresarCuentasActivosFijos();
                    break;
                case "3":
                    ingresarCuentasActivosDiferidos();
                    break;
                case "4":
                    volver = true;
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción inválida");
                    break;
            }
        }
    }

    public static void ingresarCuentasActivosCirculantes() {
        int cantidadCuentas = ingresarCantidadCuentas("Activo Circulante");
        for (int i = 0; i < cantidadCuentas; i++) {
            String nombreCuenta = JOptionPane.showInputDialog("Ingrese el nombre de la cuenta de Activo Circulante #" + (i + 1));
            int valorCuenta = ingresarValorCuenta(nombreCuenta);
            activosCirculantes.add(new Cuenta(nombreCuenta, valorCuenta, true));
        }
        JOptionPane.showMessageDialog(null, "Cuentas de Activo Circulante agregadas exitosamente");
    }

    public static void ingresarCuentasActivosFijos() {
        int cantidadCuentas = ingresarCantidadCuentas("Activos Fijos");
        for (int i = 0; i < cantidadCuentas; i++) {
            String nombreCuenta = JOptionPane.showInputDialog("Ingrese el nombre de la cuenta de Activos Fijos #" + (i + 1));
            int valorCuenta = ingresarValorCuenta(nombreCuenta);
            boolean tieneDepreciacion = preguntarSiNo("¿Esta cuenta tiene depreciación?");
            int depreciacion = 0;
            if (tieneDepreciacion) {
                depreciacion = ingresarValorDepreciacion(nombreCuenta);
                depreciacionAcumulada += depreciacion;
            }
            activosFijos.add(new Cuenta(nombreCuenta, valorCuenta, true, depreciacion));
        }
        JOptionPane.showMessageDialog(null, "Cuentas de Activos Fijos agregadas exitosamente");
    }

    public static void ingresarCuentasActivosDiferidos() {
        int cantidadCuentas = ingresarCantidadCuentas("Activos Diferidos");
        for (int i = 0; i < cantidadCuentas; i++) {
            String nombreCuenta = JOptionPane.showInputDialog("Ingrese el nombre de la cuenta de Activos Diferidos #" + (i + 1));
            int valorCuenta = ingresarValorCuenta(nombreCuenta);
            activosDiferidos.add(new Cuenta(nombreCuenta, valorCuenta, true));
        }
        JOptionPane.showMessageDialog(null, "Cuentas de Activos Diferidos agregadas exitosamente");
    }

    public static void mostrarMenuPasivos() {
        String menu = "Menu de Pasivos\n\n" +
                "1. Pasivos Circulantes\n" +
                "2. Pasivos No Circulantes\n" +
                "3. Volver al Menú de Ingreso de Datos";

        boolean volver = false;

        while (!volver) {
            String opcion = JOptionPane.showInputDialog(null, menu);
            switch (opcion) {
                case "1":
                    ingresarCuentasPasivosCirculantes();
                    break;
                case "2":
                    ingresarCuentasPasivosNoCirculantes();
                    break;
                case "3":
                    volver = true;
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción inválida");
                    break;
            }
        }
    }

    public static void ingresarCuentasPasivosCirculantes() {
        int cantidadCuentas = ingresarCantidadCuentas("Pasivos Circulantes");
        for (int i = 0; i < cantidadCuentas; i++) {
            String nombreCuenta = JOptionPane.showInputDialog("Ingrese el nombre de la cuenta de Pasivo Circulante #" + (i + 1));
            int valorCuenta = ingresarValorCuenta(nombreCuenta);
            pasivosCirculantes.add(new Cuenta(nombreCuenta, valorCuenta, false));
        }
        JOptionPane.showMessageDialog(null, "Cuentas de Pasivo Circulante agregadas exitosamente");
    }

    public static void ingresarCuentasPasivosNoCirculantes() {
        int cantidadCuentas = ingresarCantidadCuentas("Pasivos No Circulantes");
        for (int i = 0; i < cantidadCuentas; i++) {
            String nombreCuenta = JOptionPane.showInputDialog("Ingrese el nombre de la cuenta de Pasivo No Circulante #" + (i + 1));
            int valorCuenta = ingresarValorCuenta(nombreCuenta);
            pasivosNoCirculantes.add(new Cuenta(nombreCuenta, valorCuenta, false));
        }
        JOptionPane.showMessageDialog(null, "Cuentas de Pasivo No Circulante agregadas exitosamente");
    }

    public static void ingresarCuentasCapital() {
        int cantidadCuentas = ingresarCantidadCuentas("Capital");
        for (int i = 0; i < cantidadCuentas; i++) {
            String nombreCuenta = JOptionPane.showInputDialog("Ingrese el nombre de la cuenta de Capital #" + (i + 1));
            int valorCuenta = ingresarValorCuenta(nombreCuenta);
            capital.add(new Cuenta(nombreCuenta, valorCuenta, false));
        }
        JOptionPane.showMessageDialog(null, "Cuentas de Capital agregadas exitosamente");
    }

    public static int ingresarCantidadCuentas(String tipoCuenta) {
        int cantidad = 0;
        boolean cantidadValida = false;
        while (!cantidadValida) {
            try {
                String cantidadStr = JOptionPane.showInputDialog("Ingrese la cantidad de cuentas de " + tipoCuenta + " que desea ingresar");
                cantidad = Integer.parseInt(cantidadStr);
                cantidadValida = true;
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Ingrese un número válido");
            }
        }
        return cantidad;
    }

    public static int ingresarValorCuenta(String nombreCuenta) {
        int valor = 0;
        boolean valorValido = false;
        while (!valorValido) {
            try {
                String valorStr = JOptionPane.showInputDialog("Ingrese el valor de la cuenta " + nombreCuenta);
                valor = Integer.parseInt(valorStr);
                valorValido = true;
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Ingrese un número válido");
            }
        }
        return valor;
    }

    public static boolean preguntarSiNo(String pregunta) {
        int respuesta = JOptionPane.showOptionDialog(null, pregunta, "Seleccione una opción", JOptionPane.YES_NO_OPTION, JOptionPane.QUESTION_MESSAGE, null, null, null);
        return respuesta == JOptionPane.YES_OPTION;
    }

    public static int ingresarValorDepreciacion(String nombreCuenta) {
        int depreciacion = 0;
        boolean depreciacionValida = false;
        while (!depreciacionValida) {
            try {
                String depreciacionStr = JOptionPane.showInputDialog("Ingrese la cantidad de depreciación acumulada de la cuenta " + nombreCuenta);
                depreciacion = Integer.parseInt(depreciacionStr);
                depreciacionValida = true;
            } catch (NumberFormatException e) {
                JOptionPane.showMessageDialog(null, "Ingrese un número válido");
            }
        }
        return depreciacion;
    }

    public static void mostrarDatosTotales() {
        String datosTotales = "Fecha de Balance: " + fechaBalance + "\n\n" +
                "Total Activos Circulantes: " + calcularTotalActivosCirculantes() + "\n" +
                "Total Activos Fijos: " + calcularTotalActivosFijos() + "\n" +
                "Total Activos Diferidos: " + calcularTotalActivosDiferidos() + "\n" +
                "Total Pasivos Circulantes: " + calcularTotalPasivosCirculantes() + "\n" +
                "Total Pasivos No Circulantes: " + calcularTotalPasivosNoCirculantes() + "\n" +
                "Total Capital: " + calcularTotalCapital() + "\n\n" +
                "Total Activos: " + calcularTotalActivos() + "\n" +
                "Total Pasivos + Capital: " + calcularTotalPasivosCapital();

        JOptionPane.showMessageDialog(null, datosTotales);
    }

    public static int calcularTotalActivosCirculantes() {
        int total = 0;
        for (Cuenta cuenta : activosCirculantes) {
            total += cuenta.getValor();
        }
        return total;
    }

    public static int calcularTotalActivosFijos() {
        int total = 0;
        for (Cuenta cuenta : activosFijos) {
            total += cuenta.getValor() - cuenta.getDepreciacion();
        }
        return total;
    }

    public static int calcularTotalActivosDiferidos() {
        int total = 0;
        for (Cuenta cuenta : activosDiferidos) {
            total += cuenta.getValor();
        }
        return total;
    }

    public static int calcularTotalPasivosCirculantes() {
        int total = 0;
        for (Cuenta cuenta : pasivosCirculantes) {
            total += cuenta.getValor();
        }
        return total;
    }

    public static int calcularTotalPasivosNoCirculantes() {
        int total = 0;
        for (Cuenta cuenta : pasivosNoCirculantes) {
            total += cuenta.getValor();
        }
        return total;
    }

    public static int calcularTotalCapital() {
        int total = 0;
        for (Cuenta cuenta : capital) {
            total += cuenta.getValor();
        }
        return total;
    }

    public static int calcularTotalActivos() {
        return calcularTotalActivosCirculantes() + calcularTotalActivosFijos() + calcularTotalActivosDiferidos();
    }

    public static int calcularTotalPasivosCapital() {
        return calcularTotalPasivosCirculantes() + calcularTotalPasivosNoCirculantes() + calcularTotalCapital();
    }
}

class Cuenta {
    private String nombre;
    private int valor;
    private boolean esActivo;
    private int depreciacion;

    public Cuenta(String nombre, int valor, boolean esActivo) {
        this.nombre = nombre;
        this.valor = valor;
        this.esActivo = esActivo;
    }

    public Cuenta(String nombre, int valor, boolean esActivo, int depreciacion) {
        this.nombre = nombre;
        this.valor = valor;
        this.esActivo = esActivo;
        this.depreciacion = depreciacion;
    }

    public String getNombre() {
        return nombre;
    }

    public int getValor() {
        return valor;
    }

    public boolean esActivo() {
        return esActivo;
    }

    public int getDepreciacion() {
        return depreciacion;
    }
}

