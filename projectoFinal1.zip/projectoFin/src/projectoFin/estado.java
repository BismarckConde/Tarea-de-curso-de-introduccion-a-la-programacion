package projectoFin;

public class estado {
	

int Val[];

   public estado(){}

   public estado(int []Val){this.Val=Val;}

   public void setVal(int []Val){this.Val=Val;}

   public int []getVal(){return Val;}

   
   public int DT(int x,int y){return x+y;}
   public int VNTN(int x,int y){return x-y;}
   public int CMT(int x,int y){return x+y;}
   public int RT(int x,int y){return x+y;}
   public int CMN(int x,int y){return x-y;}
   public int TM(int x,int y){return x+y;}
   public int CDV(int x,int y){return x-y;}
   public int u(int x,int y){return x-y;}

   public void mostrar(int a,int b,int c,int d,int e,int f,int g,
   int h,int i,int j,int k,int l,int m,int n,int o,int p,int q)
{System.out.println("Sus ventas son: "+"\t"+"\t"+"|"+a+"|");
System.out.println("Devolucion sobre venta: "+"\t"+"|"+b+"|");
System.out.println("Descuento sobre venta: "+"\t"+"\t"+"|"+c+"|");
System.out.println("Suma de Dev/Des venta: "+"\t"+"\t"+"\t"+"|"+d+"|");
System.out.println("Ventas Netas: "+"\t"+"\t"+"\t"+"\t"+"\t"+"|"+e+"|");
System.out.println("Inventario Inicial: "+"\t"+"\t"+"\t"+"|"+f+"|");
System.out.println("Compras: "+"\t"+"\t"+"|"+g+"|");
System.out.println("Gastos de compra: "+"\t"+"|"+h+"|");
System.out.println("Compras totales: "+"\t"+"\t"+"|"+i+"|");
System.out.println("Devolucion sobre compra: "+"|"+j+"|");
System.out.println("Descuentos sobre compra: "+"|"+k+"|");
System.out.println("Suma de Dev/Des compra: "+"\t"+"|"+l+"|");
System.out.println("Compras Netas: "+"\t"+"\t"+"\t"+"\t"+"|"+m+"|");
System.out.println("Total Mercancia: "+"\t"+"\t"+"\t"+"|"+n+"|");
System.out.println("Inventario Final: "+"\t"+"\t"+"\t"+"|"+o+"|");
System.out.println("Costo de venta: "+"\t"+"\t"+"\t"+"\t"+"|"+p+"|");
System.out.println("Utilidad/Perdida bruta: "+"\t"+"\t"+"\t"+"|"+q+"|");}

   
}
