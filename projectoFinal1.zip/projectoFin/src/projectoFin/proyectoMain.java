package projectoFin;

import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
public class proyectoMain {
	private static String usuarioRegistrado;
    private static String contrasenaRegistrada;
    private static final int MAX_INTENTOS = 3;
	public static void main(String[] args) {
		boolean b=true;
        String op=" ",op0,usuario;
        int intentos=0,x,x2;
        int avan=0;
        String sop2;
        int op2;
        int c2=10;
        Boolean b2=true;
        
        while (intentos < MAX_INTENTOS) {
            int opcion = JOptionPane.showOptionDialog(null, "¿Qué desea hacer?", "Inicio de sesión",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null,
                    new String[] { "Registrarse", "Iniciar sesión", "Salir" }, null);

            switch (opcion) {
                case 0: // Registrarse
                    registrarUsuario();
                    break;
                case 1: // Iniciar sesión
                    boolean autenticado = iniciarSesion();
                    if (autenticado) {
                        JOptionPane.showMessageDialog(null, "Inicio de sesión exitoso.");
                        while(b==true) {
                            x=JOptionPane.showOptionDialog(null,"#_-¿Que desea hacer?-_#", "Menu principal",JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null,new String[] {"Menu de operaciones","\r\nManual","\r\nSalir"}, null);
                            switch(x) {
                               case 0:
                                   x2=JOptionPane.showOptionDialog(null,"#_-MENU-_#","Menu de Operaciones", JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null,new String[] {"Menu balance general","Estado de resultado","Salir del programa"}, null );
                                   switch(x2) {
                                     case 0:
                                    	 balance2 ob=new balance2();
                                         balance2.mostrarMenuPrincipal();
                                    	 break;
                                     case 1:
                                    	 String emp=JOptionPane.showInputDialog(null,"Ingrese el nombre de la empresa");
                                    	 String fecha=JOptionPane.showInputDialog(null,"Ingrese la fecha actual");
                                   		 int V[];
                                 		   int f;
                                 		   estado t=new estado();
                                 		     V=new int[42];
                                 		     try{
                                 		System.out.println("                             "+emp+"                               ");    	 
                                 		System.out.println("                             "+fecha+"                             ");
                                 		System.out.println("       *       PROGRAMA PARA CALCULAR EL ESTADO DE RESULTADO       *");
                                 		System.out.println("                                                          ");
                                 			for(f=0;f<1;f++){
                                 		String vs=JOptionPane.showInputDialog("Ingrese sus ventas:");
                                 		V[0]=Integer.parseInt(vs);
                                 		System.out.println("Sus ventas son: "+V[0]);
                                 		System.out.println("");
                                 		       do{
                                 		    	String vs2=JOptionPane.showInputDialog("Digite sus Devoluciones sobre Ventas: ");
                                 		         V[1]=Integer.parseInt(vs2);
                                 		         t.setVal(V);
                                 		       }while(V[1]<0 || V[1]>1000000);
                                 		       do{
                                 		    	String vs3=JOptionPane.showInputDialog("Digite sus Descuento sobre Ventas: ");
                                 		         V[2]=Integer.parseInt(vs3);
                                 		         t.setVal(V);
                                 		       }while(V[2]<0 || V[2]>1000000);
                                 		System.out.println("");
                                 		V[3]=t.DT(V[1],V[2]);
                                 		System.out.println("La suma de su DV/DS sobre venta es: "+V[3]);
                                 		V[4]=t.VNTN(V[0],V[3]);
                                 		System.out.println("Siendo sus Ventas Netas: "+V[4]);
                                 		System.out.println("");
                                 		       do{
                                 		    	String vs4=JOptionPane.showInputDialog("Digite sus Compras: ");
                                 		         V[6]=Integer.parseInt(vs4);
                                 		         t.setVal(V);
                                 		       }while(V[6]<0 || V[6]>1000000);
                                 		       do{
                                 		    	String vs5=JOptionPane.showInputDialog("Digite sus Gastos de compra: ");
                                 		         V[7]=Integer.parseInt(vs5);
                                 		         t.setVal(V);
                                 		       }while(V[7]<0 || V[7]>1000000);
                                 		System.out.println("");
                                 		V[8]=t.CMT(V[6],V[7]);
                                 		System.out.println("Sus compras totales son: "+V[8]);
                                 		System.out.println("");
                                 		       do{
                                 		    	String vs6=JOptionPane.showInputDialog("Digite sus Devolucion sobre Compra: ");
                                 		         V[9]=Integer.parseInt(vs6);
                                 		         t.setVal(V);
                                 		       }while(V[9]<0 || V[9]>1000000);
                                 		       do{
                                 		    	String vs7=JOptionPane.showInputDialog("Digite sus Descuento sobre Compra: ");
                                 		         V[10]=Integer.parseInt(vs7);
                                 		         t.setVal(V);
                                 		       }while(V[10]<0 || V[10]>1000000);
                                 		System.out.println("");
                                 		V[11]=t.RT(V[9],V[10]);
                                 		System.out.println("La suma de su DV/DS sobre compra es: "+V[11]);
                                 		V[12]=t.CMN(V[8],V[11]);
                                 		System.out.println("Sus compras Netas son: "+V[12]);
                                 		String v5=JOptionPane.showInputDialog(null,"ingrese su inventario inicial: ");          
                                 		V[5]=Integer.parseInt(v5);
                                 		V[13]=t.TM(V[5],V[12]);
                                 		System.out.println("Su Total Mercancia son: "+V[13]);
                                 		String v14=JOptionPane.showInputDialog(null,"Ingrese su inventario Final: ");
                                 		V[14]=Integer.parseInt(v14);
                                 		V[15]=t.CDV(V[13],V[14]);
                                 		System.out.println("El Costo de venta es: "+V[15]);
                                 		V[16]=t.u(V[4],V[15]);
                                 		if(V[16]>0)
                                 		System.out.println("Teniendo una utilidad bruta de: "+V[16]);
                                 		else
                                 		System.out.println("Teniendo una perdida bruta de: "+V[16]);                     			
                                 		System.out.println("");
                                 		System.out.println("         *           "+fecha+"       *");
                                 		System.out.println("    *    ESTADO DE RESULTADO    *");
                                 		System.out.println("");
                                 		System.out.println("CUENTAS               "+"COLUM(1)|"+"COLUM(2)|"+"COLUM(3)|"+"COLUM(4)|");
                                 		t.mostrar(V[0],V[1],V[2],V[3],V[4],V[5],V[6],V[7],V[8],V[9],V[10],V[11],V[12],V[13],V[14],V[15],V[16]);
                                 		System.out.println(" ");
                                 		
                                 		       }
                                 		     }catch(Exception ex){
                                 		      System.out.println(ex.getMessage());
                                 		     }
                                    	 break;
                                     case 2:
                                    	 JOptionPane.showMessageDialog(null,"Regresando al menu...");
                                         b=false;
                                    	 break;
                                   }
                            	   break;
                               case 1:
                            	   manualF obj=new manualF();
                                   obj.mostrarManual();
                            	   break;
                               case 2:
                            	   JOptionPane.showMessageDialog(null, "Saliendo...");
                           		   b=false;
                            	   break;
                            }
                        }
                        System.exit(0);
                    } else {
                        intentos++;
                        if (intentos < MAX_INTENTOS) {
                            JOptionPane.showMessageDialog(null, "Usuario o contraseña incorrectos. Intentos restantes: "
                                    + (MAX_INTENTOS - intentos), "Error", JOptionPane.ERROR_MESSAGE);
                        } else {
                            JOptionPane.showMessageDialog(null,
                                    "Has excedido el número de intentos, por favor abre el programa de nuevo.",
                                    "Error", JOptionPane.ERROR_MESSAGE);
                            System.exit(0);
                        }
                    }
                    break;
                case 2: // Salir
                    JOptionPane.showMessageDialog(null, "Gracias por usar el programa. ¡Hasta luego!");
                    System.exit(0);
            }
        }

	}
	private static void registrarUsuario() {
        String usuario = JOptionPane.showInputDialog(null, "Ingrese el nombre de usuario:", "Registro",
                JOptionPane.PLAIN_MESSAGE);
        JPasswordField contrasenaField = new JPasswordField();
        int opcion = JOptionPane.showConfirmDialog(null, contrasenaField, "Ingrese la contraseña:",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (opcion == JOptionPane.OK_OPTION) {
            String contrasena = new String(contrasenaField.getPassword());

            // Guardar el usuario y contraseña registrados (en un archivo, base de datos, etc.)
            usuarioRegistrado = usuario;
            contrasenaRegistrada = contrasena;

            JOptionPane.showMessageDialog(null, "Registro exitoso. Ahora puede iniciar sesión.");
        }
    }

    private static boolean iniciarSesion() {
        String usuario = JOptionPane.showInputDialog(null, "Ingrese el nombre de usuario:", "Inicio de sesión",
                JOptionPane.PLAIN_MESSAGE);
        JPasswordField contrasenaField = new JPasswordField();
        int opcion = JOptionPane.showConfirmDialog(null, contrasenaField, "Ingrese la contraseña:",
                JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);

        if (opcion == JOptionPane.OK_OPTION) {
            String contrasena = new String(contrasenaField.getPassword());

            // Verificar si el usuario y contraseña ingresados coinciden con los registrados
            return usuario.equals(usuarioRegistrado) && contrasena.equals(contrasenaRegistrada);
        }

        return false;
    }

}
