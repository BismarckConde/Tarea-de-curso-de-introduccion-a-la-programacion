package projectoFin;
import javax.swing.JOptionPane;
public class manualF {
    public void mostrarManual(){
        boolean s=true;
        boolean f1=true;
        boolean f2=true;
        boolean f3=true;

        while (s==true) {
            String i=JOptionPane.showInputDialog(null, "Bienvenido al menu del programa!!, que desea saber?"+"\n1-Acerca del programa en general"+"\n2-Acerca del menu de balance general"+"\n3-Acerca del menu de estado resultado"+"\n4-Salir del menu");
            int si=Integer.parseInt(i);
            String op;
            int sop;
            switch (si) {
                case 1:
                JOptionPane.showMessageDialog(null, "Este programa esta disñado para:"+"\n-Elaboracion de balance general"+"-\n-Elaboracion de estado de resultado"+"\n-Con tan solo la obtencion de datos");
                break;
                case 2:
                    while (f1==true) {
                    	JOptionPane.showMessageDialog(null, "Balance general:"+"\nUn balance general es un informe detallado del estado\nfinanciero de una empresa, en un lapso de tiempo determinado");
                        String opz=JOptionPane.showInputDialog(null, "Que desea saber?"+"\n1-Acerca activos"+"\n2-Acerca pasivos"+"\n3-Acerca capital"+"\n4-Volver");
                        sop=Integer.parseInt(opz);
                        switch (sop) {
                            case 1:
                                JOptionPane.showMessageDialog(null,"A continuacion se muestran: Tipos de Activos");
                                JOptionPane.showMessageDialog(null,"Activo circular:"+"\n*El activo circulante, que también se conoce como activo corriente \nson los bienes y derechos líquidos \n(en dinero) que tiene una empresa, más los bienes y derechos que pueden convertirse en líquidos en un periodo de tiempo inferior a un año.");
                                JOptionPane.showMessageDialog(null,"Activo por propiedad Planta Y equipo:"+"\n*La propiedad, planta y equipo son los activos tangibles que posee una empresa \npara su uso en la producción o suministro de bienes y servicios \n,para arrendarlos a terceros o para propósitos administrativos, y se esperan usar durante más de un período económico.");
                                JOptionPane.showMessageDialog(null,"Activo intangible:"+"\n*Un Activo Intangible es un activo que no es de naturaleza física. \nLa propiedad intelectual de las empresas (tales como patentes, marcas, derechos de autor, metodologías de negocio), buena voluntad y reconocimiento de marca, \nson activos intangibles comunes en el mercado actual.");

                                break;
                            case 2:
                                JOptionPane.showMessageDialog(null,"A continuacion se mostrara: Tipos de pasivos");
                                JOptionPane.showMessageDialog(null, "Pasivos circulares"+"\n*Parte del pasivo de una empresa que recoge las deudas exigibles a corto plazo, \nes decir, las que tendrán que ser atendidas en menos de un año \n(proveedores, acreedores comerciales, anticipos de clientes, Hacienda Pública, Seguridad Social, etc.)");
                                JOptionPane.showMessageDialog(null, "Pasivos a largo plazo"+"\n*Es decir todas los deberes financieros a pagar en un periodo mayor a un año. \n¿Solicitaste un préstamo bancario grande y te dieron la facilidad de pagarlo en cuotas diferidas en un plazo mayor a un año? \nSi tu respuesta es sí, entonces estamos hablando de que adquiriste un pasivo a largo plazo.");
                                JOptionPane.showMessageDialog(null, "Otros tipos de pasivos"+"\n*Por ejemplo: \nlas deudas con el banco, \ncompras a crédito de electrodomésticos, \nel fiado de la tienda, \nun préstamo personal recibido de un familiar, \nlos salarios de los empleados por pagar, \nlos impuestos adeudados al gobierno, \nentre muchos otros casos conforman los pasivos.");
                                break;
                            case 3:
                                JOptionPane.showMessageDialog(null,"A continuacion: Capital" );
                                JOptionPane.showMessageDialog(null, "Capital:"+"\n*El capital está formado por aquellos bienes durables (como herramientas, maquinaria o fábricas) destinados a la fabricación de otros bienes o servicios. \nTambién son capital los recursos financieros invertidos en una empresa para producir otros bienes, \nasí como las ganancias obtenidas.");

                                break;
                            case 4:
                                JOptionPane.showMessageDialog(null, "Volviendo al manual...",null,JOptionPane.INFORMATION_MESSAGE);
                                f1=false;
                                break;        
                            default:
                            	JOptionPane.showMessageDialog(null, "ERROR:Opcion no valida",null, JOptionPane.ERROR_MESSAGE);
                                break;
                        }
                    }
                    break;
                    case 3:
                    	JOptionPane.showMessageDialog(null, "Estado de resultado:"+"Estado financiero básico en el cual se presenta información relativa a los logros alcanzados"+"\n por la administración de una empresa durante un periodo determinado");
                      while(f2==true) {
                    	  String opz=JOptionPane.showInputDialog(null,"-Que quiere saber de estado de resultado?"+"\n1-Ventas netas"+"\n2-Compras totales"+"\n3-Compras netas"+"\n4-Total de mercancias"+"\n5-Costo de ventas"+"\n6-Utilidad bruta"+"\n7-salir");
                    	  sop=Integer.parseInt(opz);
                    	  switch (sop) {
                    	  case 1:
               			   JOptionPane.showMessageDialog(null,"Las ventas netas: "+"\nSe obtiene al restar las ventas de los decuentos y devolucuion de ventas");
               			  break;
               		    case 2:
               			   JOptionPane.showMessageDialog(null,"Compras totales: "+"\nLas compras totales o brutas se determinan sumando a las compras el \nvalor de los gastos de compra.");
               			  break;
               		    case 3:
               			   JOptionPane.showMessageDialog(null,"Compras netas: "+"\nEs el resultado neto de todas las compras hechas, menos las rebajas y \ndevoluciones hechas a proveedores.");
               			  break;
               		    case 4:
               			   JOptionPane.showMessageDialog(null,"Total de mercancias: "+"\nSe obtiene de sumar a la cuenta de Compras el valor del Inventario Inicial.");
               			  break;
               		    case 5:
               			   JOptionPane.showMessageDialog(null,"Costo de ventas: "+"\nEs el inventario inicial mas el costo de produccion ");
               			  break;
               		    case 6:
               			   JOptionPane.showMessageDialog(null,"Utilidad bruta: "+"\nse tiene que restar el costo de las mercancías vendidas del total de las ventas.");
               			  break;
               		    case 7:
               			   JOptionPane.showMessageDialog(null,"Volviendo al manual",null,JOptionPane.INFORMATION_MESSAGE);
               			   f2=false;
               			  break;
               		    default:
                        	JOptionPane.showMessageDialog(null, "ERROR:Opcion no valida",null, JOptionPane.ERROR_MESSAGE);
               			  break;

                    	  }
                      }
                    break;
                case 4:
                    JOptionPane.showMessageDialog(null, "Volviendo al menu principal....");
                    s=false;
                default:
                	JOptionPane.showMessageDialog(null, "ERROR:Opcion no valida",null, JOptionPane.ERROR_MESSAGE);
                    break;
            }
        }
    }

}